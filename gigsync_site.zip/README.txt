# GigSync Static Site

Pages:
- `index.html` — Landing page
- `info.html` — How it works
- `privacy.html` — Privacy Policy

All styled with `styles.css`. No build step needed — host as-is on GitHub Pages, Netlify, Vercel, etc.
